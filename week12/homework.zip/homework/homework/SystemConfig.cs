﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework
{
    public static class SystemConfig
    {
        public static string User;
        public static string Passwd;
        public static string Task;
        public static bool check;
        public static bool New;
    }
}
